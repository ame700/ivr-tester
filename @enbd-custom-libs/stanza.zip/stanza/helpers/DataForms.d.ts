import { DataFormField } from '../protocol';
export declare function mergeFields(original: DataFormField[], updated: DataFormField[]): DataFormField[];
