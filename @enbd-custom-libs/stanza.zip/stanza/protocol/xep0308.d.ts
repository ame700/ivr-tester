declare module './' {
    interface Message {
        replace?: string;
    }
}
declare const _default: import("../jxt").DefinitionOptions<any>;
export default _default;
