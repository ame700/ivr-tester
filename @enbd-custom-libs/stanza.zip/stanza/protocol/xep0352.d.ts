import { DefinitionOptions } from '../jxt';
export interface CSI {
    type: 'active' | 'inactive';
}
declare const Protocol: DefinitionOptions[];
export default Protocol;
