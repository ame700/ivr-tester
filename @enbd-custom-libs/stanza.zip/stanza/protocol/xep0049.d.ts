import { DefinitionOptions } from '../jxt';
declare module './' {
    interface IQPayload {
        privateStorage?: PrivateStorage;
    }
}
export interface PrivateStorage {
}
declare const Protocol: DefinitionOptions;
export default Protocol;
