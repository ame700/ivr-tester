import { DefinitionOptions } from '../jxt';
declare module './' {
    interface Stream {
        seeOtherURI?: string;
    }
}
declare const Protocol: DefinitionOptions[];
export default Protocol;
