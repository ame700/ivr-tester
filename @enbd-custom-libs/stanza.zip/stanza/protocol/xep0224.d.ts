declare module './' {
    interface Message {
        requestingAttention?: boolean;
    }
}
declare const _default: import("../jxt").DefinitionOptions<any>;
export default _default;
