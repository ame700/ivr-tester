import { DefinitionOptions } from '../jxt';
export interface ComponentHandshake {
    value: string;
}
declare const Protocol: DefinitionOptions;
export default Protocol;
