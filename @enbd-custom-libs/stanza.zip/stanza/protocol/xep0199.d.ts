declare module './' {
    interface IQPayload {
        ping?: boolean;
    }
}
declare const _default: import("../jxt").DefinitionOptions<any>;
export default _default;
