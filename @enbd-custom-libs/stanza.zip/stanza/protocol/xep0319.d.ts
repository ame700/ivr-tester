declare module './' {
    interface Presence {
        idleSince?: Date;
    }
}
declare const _default: import("../jxt").DefinitionOptions<any>;
export default _default;
