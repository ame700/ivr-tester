export declare function nextTick(callback: Function, ...args: any[]): void;
