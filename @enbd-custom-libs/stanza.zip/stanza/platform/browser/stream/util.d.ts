export function inherits(ctor: any, superCtor: any): void;
