export var Readable: typeof import("./lib/_stream_readable.js");
export var Writable: typeof import("./lib/_stream_writable.js");
export var Duplex: typeof import("./lib/_stream_duplex.js");
export var Transform: typeof import("./lib/_stream_transform.js");
export var PassThrough: typeof import("./lib/_stream_passthrough.js");
