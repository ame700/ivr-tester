export = PassThrough;
declare function PassThrough(options: any): PassThrough;
declare class PassThrough {
    constructor(options: any);
    _transform(chunk: any, encoding: any, cb: any): void;
}
