export class BufferList {
    head: any;
    tail: any;
    length: number;
    push(v: any): void;
    unshift(v: any): void;
    shift(): any;
    clear(): void;
    join(s: any): string;
    concat(n: any): any;
}
