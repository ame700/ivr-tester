export function destroy(err: any, cb: any): any;
export function undestroy(): void;
