import Hash from './Hash';
export { Hash };
export default function createHash(alg: string): Hash;
