export function byteLength(b64: any): number;
export function toByteArray(b64: any): any[] | Uint8Array;
export function fromByteArray(uint8: any): string;
