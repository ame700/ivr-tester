export function read(buffer: any, offset: any, isLE: any, mLen: any, nBytes: any): number;
export function write(buffer: any, value: any, offset: any, isLE: any, mLen: any, nBytes: any): void;
