export * from '../browser';
export declare const name = "react-native";
