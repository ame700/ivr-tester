"use strict";
/* istanbul ignore file */
Object.defineProperty(exports, "__esModule", { value: true });
exports.name = void 0;
const tslib_1 = require("tslib");
(0, tslib_1.__exportStar)(require("../browser"), exports);
exports.name = 'react-native';
