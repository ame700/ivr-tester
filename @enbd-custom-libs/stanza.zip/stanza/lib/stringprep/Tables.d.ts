export declare const TABLE_DATA: {
    [key: string]: {
        s?: string;
        r?: string;
        m?: string;
    };
};
