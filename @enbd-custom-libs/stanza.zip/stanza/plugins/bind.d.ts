import { Agent } from '../';
export default function (client: Agent): void;
