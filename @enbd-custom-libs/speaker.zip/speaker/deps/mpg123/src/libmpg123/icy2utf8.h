/* You expect a license plate for _this_ file? */
#ifndef MPG123_ICY2UTF_H
#define MPG123_ICY2UTF_H

#ifndef NO_ICY
/* (string, force conversion) */
char *icy2utf8(const char *, int);
#endif

#endif
