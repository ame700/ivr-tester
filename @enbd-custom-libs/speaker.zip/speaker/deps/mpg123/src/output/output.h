#ifdef __cplusplus
extern "C" {
#endif

#include "mpg123.h"
#include "module.h"
#include "audio.h"

extern mpg123_module_t mpg123_output_module_info;

#ifdef __cplusplus
}
#endif
